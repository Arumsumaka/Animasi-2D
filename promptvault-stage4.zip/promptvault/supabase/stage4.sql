-- PromptVault AI: migrasi Tahap 4a + 4b (pengguna, paket, langganan, tool premium privat)
-- Jalankan di Supabase > SQL Editor. Aman dijalankan ulang.
-- Syarat: schema.sql (Tahap 2) sudah pernah dijalankan.

-- ---------- Tool premium: file disimpan privat, bukan di URL publik ----------
alter table public.tools add column if not exists storage_path text;
alter table public.tools drop constraint if exists tools_premium_no_public_url;
alter table public.tools add constraint tools_premium_no_public_url
  check (access_type = 'free' or public_url is null) not valid;

-- ---------- Tabel ----------
create table if not exists public.plans (
  id            uuid primary key default gen_random_uuid(),
  name          text not null check (char_length(name) between 1 and 60),
  price_idr     integer not null default 0 check (price_idr >= 0),
  duration_days integer not null check (duration_days > 0),
  is_active     boolean not null default true,
  created_at    timestamptz not null default now()
);

create table if not exists public.profiles (
  user_id    uuid primary key references auth.users(id) on delete cascade,
  email      text,
  contact    text check (contact is null or char_length(contact) <= 100),
  created_at timestamptz not null default now()
);

create table if not exists public.subscriptions (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null references auth.users(id) on delete cascade,
  plan_id    uuid references public.plans(id) on delete set null,
  starts_at  timestamptz not null default now(),
  ends_at    timestamptz not null,
  source     text not null default 'manual' check (source in ('manual','payment')),
  created_at timestamptz not null default now()
);
create index if not exists subscriptions_user_idx on public.subscriptions(user_id, ends_at desc);

-- ---------- Fungsi ----------
-- Langganan aktif milik pengguna yang sedang login (memakai auth.uid(), tanpa parameter,
-- agar tidak bisa dipakai mengintip status orang lain).
create or replace function public.has_active_subscription() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.subscriptions
    where user_id = auth.uid() and starts_at <= now() and ends_at > now()
  );
$$;
revoke all on function public.has_active_subscription() from public;
grant execute on function public.has_active_subscription() to authenticated;

-- Saat akun baru dibuat, buat profil (email + kontak dari formulir daftar).
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (user_id, email, contact)
  values (new.id, new.email, left(coalesce(new.raw_user_meta_data->>'contact',''), 100))
  on conflict (user_id) do nothing;
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute function public.handle_new_user();

-- Profil untuk akun yang sudah ada (misalnya akun admin Anda).
insert into public.profiles (user_id, email)
select id, email from auth.users on conflict (user_id) do nothing;

-- ---------- Row Level Security ----------
alter table public.plans         enable row level security;
alter table public.profiles      enable row level security;
alter table public.subscriptions enable row level security;

drop policy if exists "plans_read"        on public.plans;
drop policy if exists "plans_admin_all"   on public.plans;
create policy "plans_read" on public.plans for select using (is_active = true or public.is_admin());
create policy "plans_admin_all" on public.plans for all using (public.is_admin()) with check (public.is_admin());

drop policy if exists "profiles_read_own"  on public.profiles;
drop policy if exists "profiles_update_own" on public.profiles;
drop policy if exists "profiles_admin_all" on public.profiles;
create policy "profiles_read_own" on public.profiles for select using (user_id = auth.uid() or public.is_admin());
create policy "profiles_update_own" on public.profiles for update using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "profiles_admin_all" on public.profiles for all using (public.is_admin()) with check (public.is_admin());

drop policy if exists "subs_read_own"  on public.subscriptions;
drop policy if exists "subs_admin_all" on public.subscriptions;
create policy "subs_read_own" on public.subscriptions for select using (user_id = auth.uid() or public.is_admin());
create policy "subs_admin_all" on public.subscriptions for all using (public.is_admin()) with check (public.is_admin());

-- ---------- Penyimpanan privat untuk file HTML premium ----------
insert into storage.buckets (id, name, public, file_size_limit)
values ('premium-tools', 'premium-tools', false, 5242880)
on conflict (id) do update set public = false, file_size_limit = 5242880;

drop policy if exists "premium_read"      on storage.objects;
drop policy if exists "premium_admin_all" on storage.objects;
create policy "premium_read" on storage.objects for select to authenticated
  using (bucket_id = 'premium-tools' and (public.is_admin() or public.has_active_subscription()));
create policy "premium_admin_all" on storage.objects for all to authenticated
  using (bucket_id = 'premium-tools' and public.is_admin())
  with check (bucket_id = 'premium-tools' and public.is_admin());

-- ---------- Satu paket awal (harga bisa diubah di dashboard admin) ----------
insert into public.plans (name, price_idr, duration_days)
select 'Premium Seumur Hidup', 0, 36500 where not exists (select 1 from public.plans);

-- Jika sebelumnya sudah menjalankan versi 30 hari, ubah menjadi seumur hidup:
update public.plans set name = 'Premium Seumur Hidup', duration_days = 36500 where duration_days < 36500;
