-- PromptVault AI: skema Tahap 2
-- Jalankan seluruh isi file ini di Supabase > SQL Editor > New query > Run.
-- Aman dijalankan ulang (memakai IF NOT EXISTS / OR REPLACE).

create extension if not exists pgcrypto;

-- ---------- Tabel ----------
create table if not exists public.categories (
  id         uuid primary key default gen_random_uuid(),
  name       text not null check (char_length(name) between 1 and 40),
  sort_order integer not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.tools (
  id            uuid primary key default gen_random_uuid(),
  name          text not null check (char_length(name) between 1 and 80),
  slug          text not null unique check (slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$'),
  description   text not null check (char_length(description) between 1 and 200),
  category_id   uuid not null references public.categories(id) on delete restrict,
  public_url    text check (public_url is null or public_url ~ '^https://[^\s]+\.[^\s]+$'),
  thumbnail_url text check (thumbnail_url is null or thumbnail_url ~ '^https://[^\s]+\.[^\s]+$'),
  badge         text check (badge is null or badge in ('NEW','POPULER','GRATIS','PREMIUM')),
  access_type   text not null default 'free' check (access_type in ('free','premium')),
  is_active     boolean not null default true,
  is_featured   boolean not null default false,
  sort_order    integer not null default 0 check (sort_order >= 0),
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

create index if not exists tools_category_idx on public.tools(category_id);
create index if not exists tools_sort_idx on public.tools(sort_order);

-- Daftar admin. Hanya user yang ada di tabel ini yang boleh mengubah katalog.
create table if not exists public.admins (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

-- ---------- Fungsi ----------
create or replace function public.set_updated_at() returns trigger
language plpgsql as $$
begin new.updated_at = now(); return new; end $$;

drop trigger if exists tools_set_updated_at on public.tools;
create trigger tools_set_updated_at before update on public.tools
for each row execute function public.set_updated_at();

-- Dipakai oleh kebijakan keamanan dan oleh aplikasi. security definer agar
-- bisa membaca tabel admins walau tabel itu sendiri tertutup.
create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.admins where user_id = auth.uid());
$$;
revoke all on function public.is_admin() from public;
grant execute on function public.is_admin() to anon, authenticated;

-- ---------- Row Level Security ----------
alter table public.categories enable row level security;
alter table public.tools      enable row level security;
alter table public.admins     enable row level security;

drop policy if exists "categories_read"  on public.categories;
drop policy if exists "categories_write" on public.categories;
create policy "categories_read"  on public.categories for select using (true);
create policy "categories_write" on public.categories for all
  using (public.is_admin()) with check (public.is_admin());

drop policy if exists "tools_read_active" on public.tools;
drop policy if exists "tools_admin_all"   on public.tools;
-- Pengunjung hanya melihat tool aktif. Admin melihat semuanya.
create policy "tools_read_active" on public.tools for select
  using (is_active = true or public.is_admin());
create policy "tools_admin_all" on public.tools for all
  using (public.is_admin()) with check (public.is_admin());

-- Tabel admins: tidak ada kebijakan untuk anon/authenticated, jadi tidak bisa
-- dibaca atau diubah dari browser. Isi lewat SQL Editor saja.

-- ---------- Data awal: hanya kategori (tanpa tool contoh) ----------
insert into public.categories (name, sort_order)
select v.name, v.ord from (values
  ('AI Video',10),('Edukasi & Edu',20),('ASMR',30),('Renovasi & DIY',40),('Affiliate UGC',50)
) as v(name, ord)
where not exists (select 1 from public.categories);
