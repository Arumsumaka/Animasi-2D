import type { Config } from "tailwindcss";
const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        bg: "var(--bg)", surface: "var(--surface)", surface2: "var(--surface2)", line: "var(--line)",
        fg: "var(--fg)", muted: "var(--muted)", accent: "var(--accent)", accent2: "var(--accent2)",
        ok: "var(--ok)", warn: "var(--warn)", bad: "var(--bad)",
      },
      fontFamily: { sans: ["var(--font-body)", "system-ui", "sans-serif"], display: ["var(--font-display)", "system-ui", "sans-serif"] },
    },
  },
  plugins: [],
};
export default config;
