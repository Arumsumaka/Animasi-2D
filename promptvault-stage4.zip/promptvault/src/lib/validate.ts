export function validUrl(s: string | null | undefined): boolean {
  if (!s) return false;
  try {
    const u = new URL(s);
    if (u.protocol !== "https:") return false;
    const h = u.hostname;
    if (!h.includes(".")) return false;
    if (/(^|\.)(example\.(com|org|net)|localhost|test|invalid)$/i.test(h)) return false;
    return true;
  } catch {
    return false;
  }
}
export function slugify(s: string): string {
  return s.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
}
