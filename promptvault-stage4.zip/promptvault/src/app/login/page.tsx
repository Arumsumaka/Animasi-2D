"use client";
import Link from "next/link";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { useI18n } from "@/lib/i18n";

export default function Login() {
  const { t } = useI18n();
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [pass, setPass] = useState("");
  const [err, setErr] = useState(false);
  const [busy, setBusy] = useState(false);
  const [hasNext, setHasNext] = useState(false);

  useEffect(() => { setHasNext(!!new URLSearchParams(window.location.search).get("next")); }, []);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault(); setBusy(true); setErr(false);
    const sb = createClient();
    const { error } = await sb.auth.signInWithPassword({ email: email.trim(), password: pass });
    if (error) { setBusy(false); setErr(true); return; }
    // Tujuan setelah login: halaman asal (hanya alamat internal), atau admin/akun.
    const next = new URLSearchParams(window.location.search).get("next");
    if (next && next.startsWith("/") && !next.startsWith("//")) { window.location.assign(next); return; }
    const { data: isAdmin } = await sb.rpc("is_admin");
    router.push(isAdmin === true ? "/admin" : "/akun"); router.refresh();
  };

  return (
    <div className="max-w-md">
      <h1 className="mb-4 font-display text-[26px] font-bold">{t("l_title")}</h1>
      {hasNext && <p className="mb-3 text-muted">{t("l_next_hint")}</p>}
      <form onSubmit={submit} className="flex flex-col gap-4 rounded-[14px] border border-line bg-surface p-5">
        <label className="flex flex-col gap-1.5 text-sm font-semibold" htmlFor="email">{t("l_email")}
          <input id="email" type="email" autoComplete="username" required value={email} onChange={(e) => setEmail(e.target.value)} className="font-normal" /></label>
        <label className="flex flex-col gap-1.5 text-sm font-semibold" htmlFor="pass">{t("l_pass")}
          <input id="pass" type="password" autoComplete="current-password" required value={pass} onChange={(e) => setPass(e.target.value)} className="font-normal" /></label>
        {err && <p role="alert" className="text-sm text-bad">{t("l_err")}</p>}
        <button className="btn btn-primary" disabled={busy} type="submit">{t("l_btn")}</button>
        <Link href="/daftar" className="text-sm text-accent2 underline">{t("l_register")}</Link>
      </form>
    </div>
  );
}
