"use client";
import Link from "next/link";
import { useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { useI18n } from "@/lib/i18n";

export default function Register() {
  const { t } = useI18n();
  const [email, setEmail] = useState("");
  const [pass, setPass] = useState("");
  const [contact, setContact] = useState("");
  const [err, setErr] = useState<string | null>(null);
  const [ok, setOk] = useState(false);
  const [busy, setBusy] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault(); setErr(null);
    if (pass.length < 8) { setErr(t("r_pass_short")); return; }
    if (!contact.trim()) { setErr(t("r_contact_req")); return; }
    setBusy(true);
    const { error } = await createClient().auth.signUp({
      email: email.trim(), password: pass,
      options: { data: { contact: contact.trim().slice(0, 100) }, emailRedirectTo: `${window.location.origin}/login` },
    });
    setBusy(false);
    if (error) { setErr(`${t("r_err")} (${error.message})`); return; }
    setOk(true);
  };

  if (ok) return (
    <div className="max-w-md rounded-[14px] border border-ok bg-surface p-5">
      <p role="status">{t("r_ok")}</p>
      <Link href="/login" className="mt-3 inline-block text-accent2 underline">{t("r_have")}</Link>
    </div>
  );
  return (
    <div className="max-w-md">
      <h1 className="mb-1.5 font-display text-[26px] font-bold">{t("r_title")}</h1>
      <p className="mb-4 text-muted">{t("r_lead")}</p>
      <form onSubmit={submit} className="flex flex-col gap-4 rounded-[14px] border border-line bg-surface p-5">
        <label className="flex flex-col gap-1.5 text-sm font-semibold" htmlFor="r-email">{t("r_email")}
          <input id="r-email" type="email" autoComplete="email" required value={email} onChange={(e) => setEmail(e.target.value)} className="font-normal" /></label>
        <label className="flex flex-col gap-1.5 text-sm font-semibold" htmlFor="r-pass">{t("r_pass")}
          <input id="r-pass" type="password" autoComplete="new-password" required minLength={8} value={pass} onChange={(e) => setPass(e.target.value)} className="font-normal" /></label>
        <label className="flex flex-col gap-1.5 text-sm font-semibold" htmlFor="r-contact">{t("r_contact")}
          <input id="r-contact" type="text" autoComplete="tel" required maxLength={100} value={contact} onChange={(e) => setContact(e.target.value)} className="font-normal" /></label>
        {err && <p role="alert" className="text-sm text-bad">{err}</p>}
        <button className="btn btn-primary" disabled={busy} type="submit">{t("r_btn")}</button>
        <Link href="/login" className="text-sm text-accent2 underline">{t("r_have")}</Link>
      </form>
    </div>
  );
}
