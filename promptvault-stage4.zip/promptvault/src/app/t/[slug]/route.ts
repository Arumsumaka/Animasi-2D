import { NextResponse, type NextRequest } from "next/server";
import { createClient } from "@/lib/supabase/server";

export const dynamic = "force-dynamic";

// Menyajikan tool premium. Urutan pemeriksaan:
// 1) harus login, 2) tool aktif & premium, 3) database (RLS Storage) hanya mengizinkan
// admin atau pelanggan dengan langganan aktif membaca file. Pemeriksaan ke-3 ada di database,
// jadi tidak bisa dilewati dari browser.
export async function GET(request: NextRequest, { params }: { params: { slug: string } }) {
  const sb = createClient();
  const origin = request.nextUrl.origin;
  const { data: { user } } = await sb.auth.getUser();
  if (!user) {
    const u = new URL("/login", origin);
    u.searchParams.set("next", `/t/${params.slug}`);
    return NextResponse.redirect(u);
  }
  const { data: tool } = await sb.from("tools").select("storage_path,access_type,is_active").eq("slug", params.slug).maybeSingle();
  if (!tool || !tool.is_active || tool.access_type !== "premium" || !tool.storage_path) {
    return new NextResponse("Tool tidak ditemukan.", { status: 404 });
  }
  const { data: file, error } = await sb.storage.from("premium-tools").download(tool.storage_path);
  if (error || !file) {
    const u = new URL("/akun", origin);
    u.searchParams.set("need", "premium");
    return NextResponse.redirect(u);
  }
  return new NextResponse(await file.text(), {
    status: 200,
    headers: {
      "Content-Type": "text/html; charset=utf-8",
      "Cache-Control": "private, no-store",
      "X-Content-Type-Options": "nosniff",
      "X-Robots-Tag": "noindex, nofollow",
    },
  });
}
