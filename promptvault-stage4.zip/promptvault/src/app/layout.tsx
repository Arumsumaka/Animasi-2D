import type { Metadata } from "next";
import { Sora, DM_Sans } from "next/font/google";
import "./globals.css";
import { I18nProvider } from "@/lib/i18n";
import Shell from "@/components/Shell";

const display = Sora({ subsets: ["latin"], variable: "--font-display", weight: ["600", "700"] });
const body = DM_Sans({ subsets: ["latin"], variable: "--font-body" });

export const metadata: Metadata = { title: "PromptVault AI", description: "Katalog dan pusat akses tool AI." };

const themeScript = `try{var t=localStorage.getItem('pv_theme');if(!t&&window.matchMedia('(prefers-color-scheme: light)').matches)t='light';if(t)document.documentElement.setAttribute('data-theme',t)}catch(e){}`;

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="id" className={`${display.variable} ${body.variable}`} suppressHydrationWarning>
      <head><script dangerouslySetInnerHTML={{ __html: themeScript }} /></head>
      <body className="font-sans antialiased">
        <I18nProvider><Shell>{children}</Shell></I18nProvider>
      </body>
    </html>
  );
}
