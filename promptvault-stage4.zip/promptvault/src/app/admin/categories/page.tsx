"use client";
import { useCallback, useEffect, useMemo, useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { useI18n } from "@/lib/i18n";
import type { Category } from "@/lib/types";

export default function AdminCategories() {
  const { t } = useI18n();
  const sb = useMemo(() => createClient(), []);
  const [cats, setCats] = useState<Category[]>([]);
  const [counts, setCounts] = useState<Record<string, number>>({});
  const [name, setName] = useState("");
  const [msg, setMsg] = useState<string | null>(null);
  const [delCat, setDelCat] = useState<Category | null>(null);
  const toast = (m: string) => { setMsg(m); setTimeout(() => setMsg(null), 4500); };

  const load = useCallback(async () => {
    const [a, b] = await Promise.all([sb.from("categories").select("*").order("sort_order").order("created_at"), sb.from("tools").select("category_id")]);
    if (a.error || b.error) { toast(t("load_err")); return; }
    setCats(a.data as Category[]);
    const c: Record<string, number> = {}; (b.data ?? []).forEach((r: { category_id: string }) => { c[r.category_id] = (c[r.category_id] ?? 0) + 1; }); setCounts(c);
  }, [sb, t]);
  useEffect(() => { load(); }, [load]);

  const add = async (e: React.FormEvent) => {
    e.preventDefault(); const n = name.trim(); if (!n) return;
    const { error } = await sb.from("categories").insert({ name: n, sort_order: Math.max(0, ...cats.map((c) => c.sort_order)) + 10 });
    if (error) toast(`${t("save_err")}: ${error.message}`); else { setName(""); toast(t("saved")); load(); }
  };
  const rename = async (c: Category, v: string) => {
    const n = v.trim(); if (!n || n === c.name) { load(); return; }
    const { error } = await sb.from("categories").update({ name: n }).eq("id", c.id);
    if (error) toast(`${t("save_err")}: ${error.message}`); else { toast(t("saved")); load(); }
  };
  const move = async (i: number, dir: -1 | 1) => {
    const j = i + dir; if (j < 0 || j >= cats.length) return;
    const l = [...cats]; [l[i], l[j]] = [l[j], l[i]];
    const r = await Promise.all(l.map((c, n) => sb.from("categories").update({ sort_order: (n + 1) * 10 }).eq("id", c.id)));
    if (r.some((x) => x.error)) toast(t("save_err")); load();
  };
  const remove = async () => {
    if (!delCat) return; const c = delCat; setDelCat(null);
    const { error } = await sb.from("categories").delete().eq("id", c.id);
    if (error) toast(error.code === "23503" ? t("c_blocked") : `${t("save_err")}: ${error.message}`); else load();
  };

  return (
    <div>
      <h1 className="mb-1.5 font-display text-[26px] font-bold">{t("c_title")}</h1>
      <p className="mb-5 text-muted">{t("c_lead")}</p>
      <form onSubmit={add} className="mb-4 flex flex-wrap gap-2.5">
        <input value={name} onChange={(e) => setName(e.target.value)} maxLength={40} placeholder={t("c_add")} aria-label={t("c_add")} className="min-w-[200px] flex-1" />
        <button className="btn btn-primary" type="submit">＋ {t("add")}</button>
      </form>
      <div className="flex flex-col gap-2.5">
        {cats.map((c, i) => (
          <div key={c.id} className="flex flex-wrap items-center gap-2 rounded-xl border border-line bg-surface px-3 py-2.5">
            <input key={c.name} defaultValue={c.name} maxLength={40} aria-label={c.name} onBlur={(e) => rename(c, e.target.value)} className="min-w-[160px] flex-1" />
            <span className="rounded-full border border-line bg-surface2 px-2.5 py-0.5 text-xs font-semibold">{counts[c.id] ?? 0} {t("c_used")}</span>
            <button className="btn btn-sm" disabled={i === 0} aria-label="Naik" onClick={() => move(i, -1)}>↑</button>
            <button className="btn btn-sm" disabled={i === cats.length - 1} aria-label="Turun" onClick={() => move(i, 1)}>↓</button>
            <button className="btn btn-sm btn-danger" aria-label={t("del")} onClick={() => ((counts[c.id] ?? 0) > 0 ? toast(t("c_blocked")) : setDelCat(c))}>✕</button>
          </div>
        ))}
      </div>
      {delCat && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-black/70 p-4">
          <div role="dialog" aria-modal="true" className="w-full max-w-[420px] rounded-2xl border border-line bg-surface p-5">
            <h2 className="mb-2 font-display text-lg font-semibold">{t("c_del_t")}</h2><p><b>{delCat.name}</b></p>
            <div className="mt-5 flex justify-end gap-2.5"><button className="btn" onClick={() => setDelCat(null)}>{t("cancel")}</button><button className="btn btn-danger" onClick={remove}>{t("confirm_del")}</button></div>
          </div>
        </div>
      )}
      {msg && <div role="status" className="fixed bottom-5 left-1/2 z-[60] max-w-[min(520px,calc(100%-2rem))] -translate-x-1/2 rounded-xl border border-accent2 bg-surface2 px-4 py-3 font-medium shadow-xl">{msg}</div>}
    </div>
  );
}
