"use client";
import { useCallback, useEffect, useMemo, useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { useI18n } from "@/lib/i18n";
import type { Plan } from "@/lib/types";

type Draft = { name: string; price: string; days: string; active: boolean };
const toDraft = (p: Plan): Draft => ({ name: p.name, price: String(p.price_idr), days: String(p.duration_days), active: p.is_active });

export default function AdminPlans() {
  const { t } = useI18n();
  const sb = useMemo(() => createClient(), []);
  const [plans, setPlans] = useState<Plan[]>([]);
  const [drafts, setDrafts] = useState<Record<string, Draft>>({});
  const [nw, setNw] = useState<Draft>({ name: "", price: "0", days: "30", active: true });
  const [msg, setMsg] = useState<string | null>(null);
  const toast = (m: string) => { setMsg(m); setTimeout(() => setMsg(null), 4500); };

  const load = useCallback(async () => {
    const { data, error } = await sb.from("plans").select("*").order("duration_days");
    if (error) { toast(t("load_err")); return; }
    const l = data as Plan[]; setPlans(l);
    const d: Record<string, Draft> = {}; l.forEach((p) => { d[p.id] = toDraft(p); }); setDrafts(d);
  }, [sb, t]);
  useEffect(() => { load(); }, [load]);

  const parse = (d: Draft) => {
    const name = d.name.trim();
    if (!name || !/^\d+$/.test(d.price.trim()) || !/^\d+$/.test(d.days.trim()) || parseInt(d.days, 10) < 1) return null;
    return { name, price_idr: parseInt(d.price, 10), duration_days: parseInt(d.days, 10), is_active: d.active };
  };
  const save = async (id: string) => {
    const v = parse(drafts[id]); if (!v) { toast(t("p_e")); return; }
    const { error } = await sb.from("plans").update(v).eq("id", id);
    if (error) toast(`${t("save_err")}: ${error.message}`); else { toast(t("saved")); load(); }
  };
  const add = async (e: React.FormEvent) => {
    e.preventDefault(); const v = parse(nw); if (!v) { toast(t("p_e")); return; }
    const { error } = await sb.from("plans").insert(v);
    if (error) toast(`${t("save_err")}: ${error.message}`); else { setNw({ name: "", price: "0", days: "30", active: true }); toast(t("saved")); load(); }
  };
  const upd = (id: string, patch: Partial<Draft>) => setDrafts((d) => ({ ...d, [id]: { ...d[id], ...patch } }));

  return (
    <div>
      <h1 className="mb-1.5 font-display text-[26px] font-bold">{t("p_title")}</h1>
      <p className="mb-5 text-muted">{t("p_lead")}</p>
      <div className="flex flex-col gap-2.5">
        {plans.map((p) => { const d = drafts[p.id]; if (!d) return null; return (
          <div key={p.id} className="flex flex-wrap items-end gap-2.5 rounded-xl border border-line bg-surface p-3">
            <label className="flex min-w-[160px] flex-1 flex-col gap-1 text-[13px] font-semibold">{t("p_name")}<input value={d.name} maxLength={60} onChange={(e) => upd(p.id, { name: e.target.value })} className="font-normal" /></label>
            <label className="flex w-36 flex-col gap-1 text-[13px] font-semibold">{t("p_price")}<input inputMode="numeric" value={d.price} onChange={(e) => upd(p.id, { price: e.target.value })} className="font-normal" /></label>
            <label className="flex items-center gap-2 pb-2.5 font-medium"><input type="checkbox" checked={d.active} onChange={(e) => upd(p.id, { active: e.target.checked })} /> {t("p_active")}</label>
            <button className="btn btn-sm btn-primary" onClick={() => save(p.id)}>{t("save")}</button>
          </div>); })}
      </div>
      {msg && <div role="status" className="fixed bottom-5 left-1/2 z-[60] max-w-[min(520px,calc(100%-2rem))] -translate-x-1/2 rounded-xl border border-accent2 bg-surface2 px-4 py-3 font-medium shadow-xl">{msg}</div>}
    </div>
  );
}
