"use client";
import { useCallback, useEffect, useMemo, useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { useI18n, type Key } from "@/lib/i18n";
import type { Badge, Category, Tool } from "@/lib/types";
import { slugify, validUrl } from "@/lib/validate";

type Form = { name: string; slug: string; description: string; category_id: string; public_url: string; thumbnail_url: string; badge: string; access_type: "free" | "premium"; is_active: boolean; is_featured: boolean; sort_order: string; storage_path: string };
const blank = (order: number): Form => ({ name: "", slug: "", description: "", category_id: "", public_url: "", thumbnail_url: "", badge: "", access_type: "free", is_active: true, is_featured: false, sort_order: String(order), storage_path: "" });

function Field({ k, label, hint, full, err, children }: { k: string; label: string; hint?: string; full?: boolean; err?: string; children: React.ReactNode }) {
  return (
    <div className={`flex min-w-0 flex-col gap-1.5 ${full ? "sm:col-span-2" : ""}`}>
      <label htmlFor={`f-${k}`} className="text-[13px] font-semibold">{label}</label>{children}
      {hint && <span className="text-[12.5px] text-muted">{hint}</span>}{err && <span role="alert" className="text-[12.5px] text-bad">{err}</span>}
    </div>
  );
}

export default function AdminTools() {
  const { t } = useI18n();
  const sb = useMemo(() => createClient(), []);
  const [tools, setTools] = useState<Tool[]>([]);
  const [cats, setCats] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [q, setQ] = useState(""); const [fc, setFc] = useState("all"); const [fs, setFs] = useState("all"); const [fa, setFa] = useState("all");
  const [editing, setEditing] = useState<{ id: string | null; form: Form } | null>(null);
  const [errs, setErrs] = useState<Record<string, string>>({});
  const [slugTouched, setSlugTouched] = useState(false);
  const [delTool, setDelTool] = useState<Tool | null>(null);
  const [msg, setMsg] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [file, setFile] = useState<File | null>(null);

  const toast = (m: string) => { setMsg(m); setTimeout(() => setMsg(null), 4500); };
  const load = useCallback(async () => {
    const [a, b] = await Promise.all([sb.from("tools").select("*").order("sort_order").order("created_at"), sb.from("categories").select("*").order("sort_order")]);
    if (a.error || b.error) toast(t("load_err")); else { setTools(a.data as Tool[]); setCats(b.data as Category[]); }
    setLoading(false);
  }, [sb, t]);
  useEffect(() => { load(); }, [load]);

  const catName = (id: string) => cats.find((c) => c.id === id)?.name ?? "—";
  const rows = tools.filter((x) => (fc === "all" || x.category_id === fc) && (fs === "all" || (fs === "on") === x.is_active) && (fa === "all" || x.access_type === fa) &&
    (!q.trim() || `${x.name} ${x.slug} ${x.description}`.toLowerCase().includes(q.trim().toLowerCase())));

  const patch = async (id: string, values: Partial<Tool>) => {
    const { error } = await sb.from("tools").update(values).eq("id", id);
    if (error) toast(`${t("save_err")}: ${error.message}`); else await load();
  };
  const move = async (id: string, dir: -1 | 1) => {
    const l = [...tools].sort((a, b) => a.sort_order - b.sort_order || a.created_at.localeCompare(b.created_at));
    const i = l.findIndex((x) => x.id === id), j = i + dir; if (j < 0 || j >= l.length) return;
    [l[i], l[j]] = [l[j], l[i]];
    const results = await Promise.all(l.map((x, n) => (x.sort_order !== (n + 1) * 10 ? sb.from("tools").update({ sort_order: (n + 1) * 10 }).eq("id", x.id) : Promise.resolve({ error: null }))));
    if (results.some((r) => r.error)) toast(t("save_err")); await load();
  };

  const openForm = (x: Tool | null) => {
    setErrs({}); setSlugTouched(!!x); setFile(null);
    setEditing({ id: x?.id ?? null, form: x ? { name: x.name, slug: x.slug, description: x.description, category_id: x.category_id, public_url: x.public_url ?? "", thumbnail_url: x.thumbnail_url ?? "", badge: x.badge ?? "", access_type: x.access_type, is_active: x.is_active, is_featured: x.is_featured, sort_order: String(x.sort_order), storage_path: x.storage_path ?? "" } : blank(Math.max(0, ...tools.map((v) => v.sort_order)) + 10) });
  };
  const set = <K extends keyof Form>(k: K, v: Form[K]) => setEditing((e) => {
    if (!e) return e; const form = { ...e.form, [k]: v };
    if (k === "name" && !slugTouched) form.slug = slugify(String(v));
    return { ...e, form };
  });

  const save = async (e: React.FormEvent) => {
    e.preventDefault(); if (!editing) return;
    const f = editing.form; const er: Record<string, string> = {};
    const name = f.name.trim(), slug = f.slug.trim(), desc = f.description.trim(), url = f.public_url.trim(), thumb = f.thumbnail_url.trim();
    const prem = f.access_type === "premium";
    if (!name) er.name = t("e_req");
    if (!slug) er.slug = t("e_req"); else if (!/^[a-z0-9]+(-[a-z0-9]+)*$/.test(slug)) er.slug = t("e_slug"); else if (tools.some((x) => x.slug === slug && x.id !== editing.id)) er.slug = t("e_slug_dup");
    if (!desc) er.description = t("e_req"); else if (desc.length > 200) er.description = t("e_len");
    if (!f.category_id) er.category_id = t("e_cat");
    if (!prem && url && !validUrl(url)) er.public_url = t("e_url");
    if (prem && file) { if (!/\.html?$/i.test(file.name)) er.file = t("e_file_type"); else if (file.size > 5 * 1024 * 1024) er.file = t("e_file_size"); }
    if (prem && f.is_active && !f.storage_path && !file) er.file = t("e_file_need");
    if (thumb && !validUrl(thumb)) er.thumbnail_url = t("e_thumb");
    if (!/^\d+$/.test(f.sort_order.trim())) er.sort_order = t("e_order");
    if (f.badge === "GRATIS" && f.access_type === "premium") er.badge = t("e_badge");
    setErrs(er); if (Object.keys(er).length) return;
    const row = { name, slug, description: desc, category_id: f.category_id, public_url: prem ? null : (url || null), thumbnail_url: thumb || null, badge: (f.badge || null) as Badge | null, access_type: f.access_type, is_active: f.is_active, is_featured: f.is_featured, sort_order: parseInt(f.sort_order, 10) };
    setSaving(true);
    let storagePath: string | null = prem ? (f.storage_path || null) : null;
    if (prem && file) {
      const path = `${slug}.html`;
      const up = await sb.storage.from("premium-tools").upload(path, file, { upsert: true, contentType: "text/html; charset=utf-8" });
      if (up.error) { setSaving(false); toast(`${t("up_err")}: ${up.error.message}`); return; }
      storagePath = path;
    }
    const full = { ...row, storage_path: storagePath };
    const { error } = editing.id ? await sb.from("tools").update(full).eq("id", editing.id) : await sb.from("tools").insert(full);
    setSaving(false);
    if (error) { toast(error.code === "23505" ? t("e_slug_dup") : `${t("save_err")}: ${error.message}`); return; }
    setEditing(null); toast(t("saved")); await load();
  };
  const remove = async () => {
    if (!delTool) return; const { error } = await sb.from("tools").delete().eq("id", delTool.id); setDelTool(null);
    if (error) toast(`${t("save_err")}: ${error.message}`); else { toast(t("deleted")); await load(); }
  };

  const ef = editing?.form;

  return (
    <div>
      <h1 className="mb-1.5 font-display text-[26px] font-bold">{t("a_title")}</h1>
      <p className="mb-5 max-w-[70ch] text-muted">{t("a_lead")}</p>
      <details className="mb-4 rounded-[14px] border border-line bg-surface p-4">
        <summary className="cursor-pointer font-semibold">{t("guide_t")}</summary>
        <ol className="mt-3 list-decimal space-y-2 pl-5 text-muted">{(["g1", "g2", "g3", "g4", "g5"] as Key[]).map((k) => <li key={k}>{t(k)}</li>)}</ol>
      </details>

      <div className="mb-3.5 flex flex-wrap items-center gap-2.5">
        <input type="search" value={q} onChange={(e) => setQ(e.target.value)} placeholder={t("search")} aria-label={t("search")} className="min-w-[200px] flex-1" />
        <select value={fc} onChange={(e) => setFc(e.target.value)} aria-label={t("th_cat")}><option value="all">{t("f_all_cat")}</option>{cats.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select>
        <select value={fs} onChange={(e) => setFs(e.target.value)} aria-label="Status"><option value="all">{t("f_all_status")}</option><option value="on">{t("f_active")}</option><option value="off">{t("f_inactive")}</option></select>
        <select value={fa} onChange={(e) => setFa(e.target.value)} aria-label={t("th_access")}><option value="all">{t("f_all_access")}</option><option value="free">{t("free")}</option><option value="premium">{t("premium")}</option></select>
        <button className="btn btn-primary" onClick={() => openForm(null)}>＋ {t("add")}</button>
      </div>

      <div className="overflow-x-auto rounded-[14px] border border-line bg-surface">
        <table className="w-full min-w-[860px] border-collapse text-left">
          <thead><tr className="text-muted">{(["th_order", "th_tool", "th_cat", "th_access", "th_badge", "th_url", "th_active", "th_feat", "th_act"] as Key[]).map((k) => <th key={k} className="whitespace-nowrap border-b border-line px-3 py-2.5 font-medium">{t(k)}</th>)}</tr></thead>
          <tbody>
            {loading ? <tr><td colSpan={9} className="p-7 text-center text-muted">…</td></tr>
              : rows.length === 0 ? <tr><td colSpan={9} className="p-7 text-center text-muted">{tools.length === 0 ? t("empty_db") : t("none")}</td></tr>
              : rows.map((x) => (
                <tr key={x.id} className="border-b border-line last:border-0">
                  <td className="px-3 py-2.5 font-mono text-xs">{x.sort_order}</td>
                  <td className="px-3 py-2.5"><div className="font-semibold">{x.name}</div><div className="font-mono text-xs text-muted">{x.slug}</div></td>
                  <td className="px-3 py-2.5">{catName(x.category_id)}</td>
                  <td className="px-3 py-2.5">{x.access_type === "premium" ? t("premium") : t("free")}</td>
                  <td className="px-3 py-2.5">{x.badge ?? "—"}</td>
                  <td className="px-3 py-2.5">{x.access_type === "premium" ? (x.storage_path ? <span className="text-ok">{t("url_ok")}</span> : <span className="text-muted">{t("url_empty")}</span>) : !x.public_url ? <span className="text-muted">{t("url_empty")}</span> : validUrl(x.public_url) ? <span className="text-ok">{t("url_ok")}</span> : <span className="text-bad">{t("url_bad")}</span>}</td>
                  <td className="px-3 py-2.5"><button role="switch" aria-checked={x.is_active} aria-label={t("th_active")} onClick={() => patch(x.id, { is_active: !x.is_active })}
                    className={`relative h-6 w-[42px] rounded-full border ${x.is_active ? "border-accent bg-accent" : "border-line bg-surface2"}`}><span className={`absolute top-0.5 h-[18px] w-[18px] rounded-full bg-white transition-transform ${x.is_active ? "translate-x-[20px]" : "translate-x-0.5"}`} /></button></td>
                  <td className="px-3 py-2.5"><button className="btn btn-sm" aria-pressed={x.is_featured} aria-label={t("th_feat")} onClick={() => patch(x.id, { is_featured: !x.is_featured })}>{x.is_featured ? "★" : "☆"}</button></td>
                  <td className="px-3 py-2.5"><div className="flex justify-end gap-1.5">
                    <button className="btn btn-sm" aria-label="Naik" onClick={() => move(x.id, -1)}>↑</button><button className="btn btn-sm" aria-label="Turun" onClick={() => move(x.id, 1)}>↓</button>
                    <button className="btn btn-sm" onClick={() => openForm(x)}>{t("edit")}</button><button className="btn btn-sm btn-danger" aria-label={t("del")} onClick={() => setDelTool(x)}>✕</button></div></td>
                </tr>))}
          </tbody>
        </table>
      </div>

      {editing && ef && (
        <div className="fixed inset-0 z-50 grid place-items-center overflow-y-auto bg-black/70 p-4" onMouseDown={(e) => { if (e.target === e.currentTarget) setEditing(null); }}>
          <form onSubmit={save} noValidate role="dialog" aria-modal="true" className="max-h-full w-full max-w-[640px] overflow-y-auto rounded-2xl border border-line bg-surface p-5 shadow-2xl">
            <h2 className="mb-3.5 font-display text-lg font-semibold">{editing.id ? t("dlg_edit") : t("dlg_add")}</h2>
            <div className="grid gap-3.5 sm:grid-cols-2">
              <Field k="name" err={errs.name} label={`${t("f_name")} *`}><input id="f-name" value={ef.name} maxLength={80} onChange={(e) => set("name", e.target.value)} /></Field>
              <Field k="slug" err={errs.slug} label={`${t("f_slug")} *`} hint={t("f_slug_h")}><input id="f-slug" value={ef.slug} maxLength={80} onChange={(e) => { setSlugTouched(true); set("slug", e.target.value); }} /></Field>
              <Field k="description" err={errs.description} label={`${t("f_desc")} *`} full><textarea id="f-description" rows={3} maxLength={200} value={ef.description} onChange={(e) => set("description", e.target.value)} /></Field>
              <Field k="category_id" err={errs.category_id} label={`${t("f_cat")} *`}><select id="f-category_id" value={ef.category_id} onChange={(e) => set("category_id", e.target.value)}><option value="">{t("f_cat_ph")}</option>{cats.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select></Field>
              <Field k="badge" err={errs.badge} label={t("f_badge")}><select id="f-badge" value={ef.badge} onChange={(e) => set("badge", e.target.value)}><option value="">{t("f_none")}</option>{["NEW", "POPULER", "GRATIS", "PREMIUM"].map((b) => <option key={b}>{b}</option>)}</select></Field>
              {ef.access_type !== "premium"
                ? <Field k="public_url" err={errs.public_url} label={t("f_url")} hint={t("f_url_h")} full><input id="f-public_url" type="url" inputMode="url" placeholder="https://" value={ef.public_url} onChange={(e) => set("public_url", e.target.value)} /></Field>
                : <Field k="file" err={errs.file} label={t("f_file")} hint={ef.storage_path ? `${t("f_file_cur")} ${ef.storage_path}` : t("f_file_h")} full><input id="f-file" type="file" accept=".html,.htm,text/html" onChange={(e) => setFile(e.target.files?.[0] ?? null)} /></Field>}
              <Field k="thumbnail_url" err={errs.thumbnail_url} label={t("f_thumb")} hint={t("f_thumb_h")} full><input id="f-thumbnail_url" type="url" inputMode="url" placeholder="https://" value={ef.thumbnail_url} onChange={(e) => set("thumbnail_url", e.target.value)} /></Field>
              <Field k="access_type" err={errs.access_type} label={t("f_access")}><select id="f-access_type" value={ef.access_type} onChange={(e) => set("access_type", e.target.value as "free" | "premium")}><option value="free">{t("free")}</option><option value="premium">{t("premium")}</option></select></Field>
              <Field k="sort_order" err={errs.sort_order} label={`${t("f_order")} *`}><input id="f-sort_order" type="number" min={0} step={1} value={ef.sort_order} onChange={(e) => set("sort_order", e.target.value)} /></Field>
              <div className="flex flex-wrap gap-5 sm:col-span-2">
                <label className="flex items-center gap-2 font-medium"><input type="checkbox" checked={ef.is_active} onChange={(e) => set("is_active", e.target.checked)} /> {t("f_active_l")}</label>
                <label className="flex items-center gap-2 font-medium"><input type="checkbox" checked={ef.is_featured} onChange={(e) => set("is_featured", e.target.checked)} /> {t("f_feat_l")}</label>
              </div>
            </div>
            <div className="mt-5 flex flex-wrap justify-end gap-2.5">
              <button type="button" className="btn" onClick={() => setEditing(null)}>{t("cancel")}</button>
              <button type="submit" className="btn btn-primary" disabled={saving}>{t("save")}</button>
            </div>
          </form>
        </div>
      )}
      {delTool && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-black/70 p-4">
          <div role="dialog" aria-modal="true" className="w-full max-w-[420px] rounded-2xl border border-line bg-surface p-5">
            <h2 className="mb-2 font-display text-lg font-semibold">{t("del_t")}</h2>
            <p className="text-muted">{t("del_m")} <b className="text-fg">{delTool.name}</b></p>
            <div className="mt-5 flex justify-end gap-2.5"><button className="btn" onClick={() => setDelTool(null)}>{t("cancel")}</button><button className="btn btn-danger" onClick={remove}>{t("confirm_del")}</button></div>
          </div>
        </div>
      )}
      {msg && <div role="status" className="fixed bottom-5 left-1/2 z-[60] max-w-[min(520px,calc(100%-2rem))] -translate-x-1/2 rounded-xl border border-accent2 bg-surface2 px-4 py-3 font-medium shadow-xl">{msg}</div>}
    </div>
  );
}
