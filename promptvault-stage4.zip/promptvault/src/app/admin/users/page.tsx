"use client";
import { useCallback, useEffect, useMemo, useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { useI18n } from "@/lib/i18n";
import type { Plan, Profile, Subscription } from "@/lib/types";

const isLifetime = (iso: string) => new Date(iso).getFullYear() >= 2100;
const fmt = (iso: string) => new Date(iso).toLocaleDateString("id-ID", { day: "numeric", month: "short", year: "numeric" });

export default function AdminUsers() {
  const { t } = useI18n();
  const sb = useMemo(() => createClient(), []);
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [subs, setSubs] = useState<Subscription[]>([]);
  const [plans, setPlans] = useState<Plan[]>([]);
  const [q, setQ] = useState("");
  const [msg, setMsg] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const toast = (m: string) => { setMsg(m); setTimeout(() => setMsg(null), 4500); };

  const load = useCallback(async () => {
    const [a, b, c] = await Promise.all([
      sb.from("profiles").select("*").order("created_at", { ascending: false }),
      sb.from("subscriptions").select("*"),
      sb.from("plans").select("*").eq("is_active", true).order("duration_days"),
    ]);
    if (a.error || b.error || c.error) toast(t("load_err"));
    else { setProfiles(a.data as Profile[]); setSubs(b.data as Subscription[]); setPlans(c.data as Plan[]); }
    setLoading(false);
  }, [sb, t]);
  useEffect(() => { load(); }, [load]);

  const activeEnd = (uid: string): string | null => {
    const now = Date.now();
    const ends = subs.filter((s) => s.user_id === uid && new Date(s.starts_at).getTime() <= now && new Date(s.ends_at).getTime() > now).map((s) => s.ends_at);
    return ends.length ? ends.reduce((m, x) => (x > m ? x : m), ends[0]) : null;
  };

  const activate = async (uid: string) => {
    const plan = plans[0];
    if (!plan) return;
    const end = activeEnd(uid);
    if (end && isLifetime(end)) { toast(t("u_already")); return; }
    const endsAt = new Date(Date.now() + plan.duration_days * 86400000).toISOString();
    const { error } = await sb.from("subscriptions").insert({ user_id: uid, plan_id: plan.id, starts_at: new Date().toISOString(), ends_at: endsAt, source: "manual" });
    if (error) toast(`${t("save_err")}: ${error.message}`); else { toast(t("u_done")); load(); }
  };
  const cancel = async (uid: string) => {
    const nowIso = new Date().toISOString();
    const { error } = await sb.from("subscriptions").update({ ends_at: nowIso }).eq("user_id", uid).gt("ends_at", nowIso);
    if (error) toast(`${t("save_err")}: ${error.message}`); else { toast(t("u_done")); load(); }
  };

  const rows = profiles.filter((p) => !q.trim() || `${p.email ?? ""} ${p.contact ?? ""}`.toLowerCase().includes(q.trim().toLowerCase()));

  return (
    <div>
      <h1 className="mb-1.5 font-display text-[26px] font-bold">{t("u_title")}</h1>
      <p className="mb-1 max-w-[70ch] text-muted">{t("u_lead")}</p>
      <p className="mb-5 max-w-[70ch] text-sm text-muted">{t("u_note")}</p>
      <input type="search" value={q} onChange={(e) => setQ(e.target.value)} placeholder={t("search")} aria-label={t("search")} className="mb-3.5 w-full max-w-md" />
      <div className="overflow-x-auto rounded-[14px] border border-line bg-surface">
        <table className="w-full min-w-[820px] border-collapse text-left">
          <thead><tr className="text-muted">{(["th_email", "th_contact", "th_joined", "th_sub", "th_act"] as const).map((k) => <th key={k} className="whitespace-nowrap border-b border-line px-3 py-2.5 font-medium">{t(k)}</th>)}</tr></thead>
          <tbody>
            {loading ? <tr><td colSpan={5} className="p-7 text-center text-muted">…</td></tr>
              : rows.length === 0 ? <tr><td colSpan={5} className="p-7 text-center text-muted">{t("u_empty")}</td></tr>
              : rows.map((p) => {
                const end = activeEnd(p.user_id);
                return (
                  <tr key={p.user_id} className="border-b border-line last:border-0">
                    <td className="px-3 py-2.5 font-medium">{p.email ?? "—"}</td>
                    <td className="px-3 py-2.5">{p.contact || "—"}</td>
                    <td className="px-3 py-2.5 text-muted">{p.created_at ? fmt(p.created_at) : "—"}</td>
                    <td className="px-3 py-2.5">{end ? <span className="text-ok">{isLifetime(end) ? t("lifetime") : `${t("u_until")} ${fmt(end)}`}</span> : <span className="text-muted">{t("u_none")}</span>}</td>
                    <td className="px-3 py-2.5">
                      <div className="flex flex-wrap items-center justify-end gap-1.5">
                        <button className="btn btn-sm btn-primary" disabled={plans.length === 0} onClick={() => activate(p.user_id)}>{t("u_activate")}</button>
                        {end && <button className="btn btn-sm btn-danger" onClick={() => cancel(p.user_id)}>{t("u_cancel")}</button>}
                      </div>
                    </td>
                  </tr>
                );
              })}
          </tbody>
        </table>
      </div>
      {msg && <div role="status" className="fixed bottom-5 left-1/2 z-[60] max-w-[min(520px,calc(100%-2rem))] -translate-x-1/2 rounded-xl border border-accent2 bg-surface2 px-4 py-3 font-medium shadow-xl">{msg}</div>}
    </div>
  );
}
