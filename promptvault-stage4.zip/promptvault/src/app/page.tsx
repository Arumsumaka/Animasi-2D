import { createClient } from "@/lib/supabase/server";
import Catalog from "@/components/Catalog";
import type { Category, Tool } from "@/lib/types";

export const dynamic = "force-dynamic";

export default async function Home({ searchParams }: { searchParams: { denied?: string } }) {
  const sb = createClient();
  // RLS: pengunjung biasa hanya menerima tool aktif.
  const [toolsRes, catsRes] = await Promise.all([
    sb.from("tools").select("*").eq("is_active", true).order("sort_order"),
    sb.from("categories").select("*").order("sort_order"),
  ]);
  const error = !!(toolsRes.error || catsRes.error);
  return (
    <Catalog
      tools={(toolsRes.data ?? []) as Tool[]}
      categories={(catsRes.data ?? []) as Category[]}
      error={error}
      denied={searchParams.denied === "1"}
    />
  );
}
