"use client";
import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { useI18n } from "@/lib/i18n";
import type { Plan, Profile, Subscription } from "@/lib/types";

const isLifetime = (iso: string) => new Date(iso).getFullYear() >= 2100;
const fmtDate = (iso: string) => new Date(iso).toLocaleDateString("id-ID", { day: "numeric", month: "long", year: "numeric" });

export default function Account() {
  const { t } = useI18n();
  const router = useRouter();
  const sb = useMemo(() => createClient(), []);
  const [ready, setReady] = useState(false);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [subs, setSubs] = useState<Subscription[]>([]);
  const [plans, setPlans] = useState<Plan[]>([]);
  const [need, setNeed] = useState(false);

  useEffect(() => {
    setNeed(new URLSearchParams(window.location.search).get("need") === "premium");
    (async () => {
      const { data: { user } } = await sb.auth.getUser();
      if (!user) { router.replace("/login?next=/akun"); return; }
      const [p, s, pl] = await Promise.all([
        sb.from("profiles").select("*").eq("user_id", user.id).maybeSingle(),
        sb.from("subscriptions").select("*").eq("user_id", user.id).order("ends_at", { ascending: false }),
        sb.from("plans").select("*").eq("is_active", true).order("duration_days"),
      ]);
      setProfile((p.data as Profile) ?? { user_id: user.id, email: user.email ?? null, contact: null, created_at: "" });
      setSubs((s.data ?? []) as Subscription[]); setPlans((pl.data ?? []) as Plan[]); setReady(true);
    })();
  }, [sb, router]);

  if (!ready) return <p className="text-muted">…</p>;
  const now = Date.now();
  const active = subs.filter((x) => new Date(x.starts_at).getTime() <= now && new Date(x.ends_at).getTime() > now);
  const until = active.length ? active.reduce((m, x) => (x.ends_at > m ? x.ends_at : m), active[0].ends_at) : null;
  const last = subs[0]?.ends_at;
  const wa = (process.env.NEXT_PUBLIC_ADMIN_WHATSAPP ?? "").replace(/\D/g, "");

  return (
    <div className="max-w-xl">
      <h1 className="mb-4 font-display text-[26px] font-bold">{t("acc_title")}</h1>
      {need && <p role="alert" className="mb-4 rounded-xl border border-warn p-3 text-sm">{t("acc_need")}</p>}
      <div className="mb-4 rounded-[14px] border border-line bg-surface p-5">
        <div className="text-sm text-muted">{t("acc_email")}</div><div className="mb-3 font-semibold">{profile?.email}</div>
        {profile?.contact && <><div className="text-sm text-muted">{t("acc_contact")}</div><div className="mb-3 font-semibold">{profile.contact}</div></>}
        <div className="text-sm text-muted">{t("acc_status")}</div>
        <div className={`font-semibold ${until ? "text-ok" : ""}`}>
          {until ? (isLifetime(until) ? `${t("acc_status")}: ${t("lifetime")}` : `${t("acc_active")} ${fmtDate(until)}`) : last ? `${t("acc_none")} (${t("acc_expired")} ${fmtDate(last)})` : t("acc_none")}
        </div>
      </div>
      {!until && (
        <div className="rounded-[14px] border border-line bg-surface p-5">
          <p className="mb-3 text-muted">{t("acc_buy")}</p>
          {plans.length > 0 && (
            <ul className="mb-3 space-y-1.5">
              <li className="mono-label text-muted">{t("acc_plans")}</li>
              {plans.map((p) => <li key={p.id} className="font-medium">{p.name} · {p.duration_days >= 36500 ? t("lifetime") : `${p.duration_days} ${t("acc_days")}`}{p.price_idr > 0 ? ` · Rp ${p.price_idr.toLocaleString("id-ID")}` : ""}</li>)}
            </ul>
          )}
          {wa && <a className="btn btn-primary" href={`https://wa.me/${wa}`} target="_blank" rel="noopener noreferrer">{t("acc_wa")}</a>}
        </div>
      )}
    </div>
  );
}
