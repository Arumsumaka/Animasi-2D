"use client";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState, type ReactNode } from "react";
import { createClient } from "@/lib/supabase/client";
import { useI18n } from "@/lib/i18n";

export default function Shell({ children }: { children: ReactNode }) {
  const { t, lang, setLang } = useI18n();
  const path = usePathname();
  const router = useRouter();
  const [isAdmin, setIsAdmin] = useState(false);
  const [loggedIn, setLoggedIn] = useState(false);
  const [dark, setDark] = useState(true);

  useEffect(() => {
    setDark(document.documentElement.getAttribute("data-theme") !== "light");
    const sb = createClient();
    const check = async () => {
      const { data: { user } } = await sb.auth.getUser();
      setLoggedIn(!!user);
      if (user) { const { data } = await sb.rpc("is_admin"); setIsAdmin(data === true); } else setIsAdmin(false);
    };
    check();
    const { data: sub } = sb.auth.onAuthStateChange(() => { check(); });
    return () => sub.subscription.unsubscribe();
  }, []);

  const toggleTheme = () => {
    const next = dark ? "light" : "dark";
    document.documentElement.setAttribute("data-theme", next);
    try { localStorage.setItem("pv_theme", next); } catch {}
    setDark(!dark);
  };
  const logout = async () => { await createClient().auth.signOut(); router.push("/"); router.refresh(); };

  const link = (href: string, label: string) => {
    const active = href === "/" ? path === "/" : path.startsWith(href) && (href !== "/admin" || path === "/admin");
    return (
      <Link href={href} aria-current={active ? "page" : undefined}
        className={`whitespace-nowrap rounded-[10px] px-3 py-2.5 font-medium ${active ? "bg-accent text-white" : "text-muted hover:bg-surface hover:text-fg"}`}>
        {label}
      </Link>
    );
  };

  return (
    <div className="mx-auto max-w-[1400px] px-4">
      <header className="sticky top-0 z-20 flex h-[68px] items-center justify-between gap-3 border-b border-line bg-bg">
        <Link href="/" className="flex items-center gap-3">
          <span className="grid h-10 w-10 place-items-center rounded-[11px] bg-gradient-to-br from-accent to-accent2 font-display text-sm font-bold text-white">PV</span>
          <span className="hidden sm:block">
            <b className="block font-display text-lg">Prompt<span className="text-accent2">Vault</span> AI</b>
            <span className="mono-label block text-muted">{t("tagline")}</span>
          </span>
        </Link>
        <div className="flex items-center gap-2">
          <button onClick={toggleTheme} className="btn h-[38px] w-[38px] !p-0" aria-label="Tema">{dark ? "☀" : "☾"}</button>
          <div className="flex rounded-[10px] border border-line bg-surface p-[3px]" role="group" aria-label="Bahasa">
            {(["id", "en"] as const).map((l) => (
              <button key={l} aria-pressed={lang === l} onClick={() => setLang(l)}
                className={`rounded-[7px] px-3 py-1.5 font-mono text-xs font-medium ${lang === l ? "bg-accent text-white" : "text-muted"}`}>{l.toUpperCase()}</button>
            ))}
          </div>
        </div>
      </header>
      <div className="grid gap-4 pt-5 pb-10 md:grid-cols-[220px_minmax(0,1fr)] md:gap-7">
        <nav className="flex gap-1.5 overflow-x-auto md:sticky md:top-24 md:flex-col md:self-start md:overflow-visible">
          {link("/", t("nav_catalog"))}
          {loggedIn && link("/akun", t("nav_account"))}
          {isAdmin && link("/admin", t("nav_admin"))}
          {isAdmin && link("/admin/categories", t("nav_cats"))}
          {isAdmin && link("/admin/users", t("nav_users"))}
          {isAdmin && link("/admin/plans", t("nav_plans"))}
          {loggedIn
            ? <button onClick={logout} className="whitespace-nowrap rounded-[10px] px-3 py-2.5 text-left font-medium text-bad hover:bg-surface">{t("logout")}</button>
            : <>{link("/login", t("nav_login"))}{link("/daftar", t("register"))}</>}
        </nav>
        <main className="min-w-0">{children}</main>
      </div>
    </div>
  );
}
