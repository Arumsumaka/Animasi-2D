"use client";
import { useMemo, useState } from "react";
import type { Category, Tool } from "@/lib/types";
import { useI18n, type Key } from "@/lib/i18n";
import { validUrl } from "@/lib/validate";

const badgeCls: Record<string, string> = {
  NEW: "bg-accent text-white", POPULER: "bg-[#e0568a] text-white", GRATIS: "bg-ok text-[#06251a]", PREMIUM: "bg-warn text-[#2b1c00]",
};

export default function Catalog({ tools, categories, error, denied }: { tools: Tool[]; categories: Category[]; error: boolean; denied: boolean }) {
  const { t } = useI18n();
  const [q, setQ] = useState("");
  const [cat, setCat] = useState("all");
  const [sort, setSort] = useState("order");
  const [favOnly, setFavOnly] = useState(false);
  const [favs, setFavs] = useState<Set<string>>(new Set());
  const [msg, setMsg] = useState<string | null>(null);

  const catName = (id: string) => categories.find((c) => c.id === id)?.name ?? "—";
  const list = useMemo(() => {
    const s = q.trim().toLowerCase();
    const l = tools.filter((x) =>
      (cat === "all" || x.category_id === cat) && (!favOnly || favs.has(x.id)) &&
      (!s || `${x.name} ${x.description} ${catName(x.category_id)}`.toLowerCase().includes(s)));
    if (sort === "new") l.sort((a, b) => b.created_at.localeCompare(a.created_at));
    else if (sort === "az") l.sort((a, b) => a.name.localeCompare(b.name));
    else if (sort === "feat") l.sort((a, b) => Number(b.is_featured) - Number(a.is_featured) || a.sort_order - b.sort_order);
    else l.sort((a, b) => a.sort_order - b.sort_order);
    return l;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tools, q, cat, sort, favOnly, favs, categories]);

  const toast = (m: string) => { setMsg(m); setTimeout(() => setMsg(null), 4500); };
  const blocked = (x: Tool) => toast(x.access_type === "premium" || !x.public_url ? t("m_nourl") : t("m_badurl"));
  const toggleFav = (id: string) => setFavs((p) => { const n = new Set(p); n.has(id) ? n.delete(id) : n.add(id); return n; });

  return (
    <div>
      {denied && <p className="mb-4 rounded-xl border border-warn p-3 text-sm">{t("denied")}</p>}
      {error && <p className="mb-4 rounded-xl border border-bad p-3 text-sm">{t("load_err")}</p>}
      <h1 className="mb-1.5 font-display text-[26px] font-bold">{t("cat_title")}</h1>
      <p className="mb-5 max-w-[70ch] text-muted">{t("cat_lead")}</p>

      <div className="rounded-[14px] border border-line bg-surface p-4">
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder={t("search")} aria-label={t("search")} type="search" className="w-full" />
        <div className="mt-3 flex flex-wrap items-center gap-2">
          <span className="mono-label text-muted">{t("filter")}:</span>
          {[{ id: "all", name: t("all") }, ...categories].map((c) => (
            <button key={c.id} aria-pressed={cat === c.id} onClick={() => setCat(c.id)}
              className={`rounded-full border px-3.5 py-1.5 text-sm font-medium ${cat === c.id ? "border-accent bg-accent text-white" : "border-line bg-surface2"}`}>
              {c.name}<small className="ml-1.5 opacity-70">{c.id === "all" ? tools.length : tools.filter((x) => x.category_id === c.id).length}</small>
            </button>
          ))}
        </div>
      </div>

      <div className="my-4 flex flex-wrap items-center justify-between gap-3 text-muted">
        <div>{t("showing")} <b className="text-fg">{list.length}</b> {t("tools")} {t("in")} <b className="text-fg">{cat === "all" ? t("all").toLowerCase() : catName(cat)}</b></div>
        <div className="flex flex-wrap items-center gap-2.5">
          <button aria-pressed={favOnly} onClick={() => setFavOnly(!favOnly)}
            className={`rounded-full border px-3.5 py-1.5 text-sm font-medium ${favOnly ? "border-accent bg-accent text-white" : "border-line bg-surface2 text-fg"}`}>{t("favonly")}</button>
          <select value={sort} onChange={(e) => setSort(e.target.value)} aria-label={t("sort")}>
            {([["order", "s_order"], ["new", "s_new"], ["az", "s_az"], ["feat", "s_feat"]] as [string, Key][]).map(([v, k]) => <option key={v} value={v}>{t(k)}</option>)}
          </select>
        </div>
      </div>

      {list.length === 0 ? (
        <div className="rounded-[14px] border border-dashed border-line p-10 text-center text-muted">{tools.length === 0 ? t("empty_db") : t("none")}</div>
      ) : (
        <div className="grid grid-cols-[repeat(auto-fill,minmax(250px,1fr))] gap-4">
          {list.map((x) => {
            const prem = x.access_type === "premium"; const ok = prem ? !!x.storage_path : validUrl(x.public_url);
            return (
              <article key={x.id} className="flex min-w-0 flex-col overflow-hidden rounded-[14px] border border-line bg-surface">
                <div className="relative grid h-28 place-items-center overflow-hidden bg-gradient-to-br from-surface2 to-bg">
                  <span className="font-display text-3xl font-bold text-accent2 opacity-85">{x.name.slice(0, 2).toUpperCase()}</span>
                  {validUrl(x.thumbnail_url) && /* eslint-disable-next-line @next/next/no-img-element */
                    <img src={x.thumbnail_url!} alt="" loading="lazy" className="absolute inset-0 h-full w-full object-cover" onError={(e) => e.currentTarget.remove()} />}
                </div>
                <div className="flex flex-1 flex-col gap-2 p-4">
                  <div className="flex items-center justify-between gap-2">
                    <span className="mono-label max-w-[70%] truncate rounded-md bg-surface2 px-2 py-0.5 text-accent2">{catName(x.category_id)}</span>
                    {x.badge && <span className={`rounded-md px-2 py-0.5 font-mono text-[11px] font-semibold ${badgeCls[x.badge]}`}>{x.badge}</span>}
                  </div>
                  <h3 className="break-words font-display text-[17px] font-semibold leading-snug">{x.name}</h3>
                  <p className="line-clamp-3 flex-1 text-sm text-muted">{x.description}</p>
                  <div className="mono-label flex flex-wrap gap-2.5 text-muted">
                    <span>{prem ? t("premium") : t("free")}</span>{x.is_featured && <span>★ {t("feat")}</span>}{!ok && <span className="text-warn">{t("offline")}</span>}
                  </div>
                  <div className="mt-1 flex gap-2">
                    {ok
                      ? <a className="btn btn-primary flex-1" href={prem ? `/t/${x.slug}` : x.public_url!} target="_blank" rel="noopener noreferrer">{t("open")} ↗</a>
                      : <button className="btn btn-primary flex-1" onClick={() => blocked(x)}>{t("open")} ↗</button>}
                    <button className="btn" aria-pressed={favs.has(x.id)} aria-label="Favorit" onClick={() => toggleFav(x.id)}>{favs.has(x.id) ? "★" : "☆"}</button>
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      )}
      {msg && <div role="status" className="fixed bottom-5 left-1/2 z-50 max-w-[min(520px,calc(100%-2rem))] -translate-x-1/2 rounded-xl border border-accent2 bg-surface2 px-4 py-3 font-medium shadow-xl">{msg}</div>}
    </div>
  );
}
