# PromptVault AI (Tahap 4a + 4b)

Katalog tool AI berbasis HTML. Data dibaca dari Supabase dan dikelola lewat dashboard admin.
Tahap ini sudah mencakup: skema database + keamanan (RLS), katalog dari database, CRUD admin, login admin.
Belum ada: pendaftaran pengguna umum, paket berlangganan, pembayaran, upload file lewat dashboard.

## Langkah 1. Siapkan komputer
1. Pasang Node.js versi LTS dari https://nodejs.org (pilih tombol LTS, klik Next sampai selesai).
2. Ekstrak file zip proyek ini, lalu buka folder `promptvault` di terminal.
   (Windows: klik kanan di dalam folder > "Open in Terminal".)

## Langkah 2. Buat database di Supabase
1. Masuk ke https://supabase.com/dashboard, buka project Anda (atau klik New project).
2. Menu kiri **SQL Editor** > **New query**.
3. Buka file `supabase/schema.sql` dengan Notepad, salin semua isinya, tempel ke SQL Editor, klik **Run**.
   Hasil yang benar: tulisan "Success. No rows returned". File ini boleh dijalankan ulang.

## Langkah 3. Buat akun admin
1. Menu kiri **Authentication** > **Users** > **Add user** > **Create new user**.
2. Isi email dan kata sandi Anda. Centang **Auto Confirm User**. Klik Create.
3. Kembali ke **SQL Editor**, jalankan query ini (ganti email dengan email tadi):
   ```sql
   insert into public.admins (user_id)
   select id from auth.users where email = 'EMAIL_ANDA@contoh.com';
   ```
   Hanya akun yang terdaftar di tabel `admins` yang bisa mengubah katalog. Cek: `select * from public.admins;` harus menampilkan 1 baris.

## Langkah 4. Hubungkan website ke Supabase
1. Di Supabase buka **Project Settings** > **API** (atau **API Keys**).
2. Catat **Project URL** dan kunci **anon / public** (jika yang tampil hanya "publishable key", itu juga boleh dipakai; kalau ada error login, cari bagian "Legacy API keys" untuk anon key).
3. Di folder proyek, salin `.env.example` menjadi `.env.local`, lalu isi:
   ```
   NEXT_PUBLIC_SUPABASE_URL=...Project URL...
   NEXT_PUBLIC_SUPABASE_ANON_KEY=...anon key...
   ```
4. **Jangan** memakai atau menyalin kunci `service_role` ke proyek ini. Kunci itu melewati semua keamanan.

## Langkah 5. Jalankan
```
npm install
npm run dev
```
Buka http://localhost:3000.

## Langkah 6. Uji nyata (centang satu per satu)
- [ ] Halaman utama terbuka dan menampilkan "Katalog masih kosong" (5 kategori sudah ada sebagai filter).
- [ ] Buka /login, masuk dengan akun admin. Menu "Kelola Tool" dan "Kategori" muncul.
- [ ] Tambah tool dengan URL kosong: tersimpan, kartu tampil "Belum online", tombol Buka Tool menampilkan pesan.
- [ ] Coba isi URL `C:\file.html` atau `http://localhost`: formulir menolak.
- [ ] Isi URL https yang benar: kartu menjadi link tab baru.
- [ ] Matikan saklar Aktif: tool hilang dari halaman utama setelah dimuat ulang.
- [ ] Hapus tool: muncul konfirmasi.
- [ ] Keluar, lalu buka /admin: Anda dialihkan ke /login.
- [ ] Uji keamanan database: masuk dengan akun lain yang bukan admin lalu buka /admin. Harus ditolak dan kembali ke halaman utama.

## Catatan keamanan yang jujur
- Pengamanan admin ada di database (RLS), bukan di tombol atau menu. Middleware hanya pengalih halaman.
- Tool **premium** belum terlindungi. URL tool premium masih bisa dibaca dari database oleh siapa pun yang tahu cara memanggil API publik Supabase. Proteksi nyata dikerjakan di Tahap 4: tool premium harus memeriksa login/langganan di sisi tool atau backend-nya sendiri.
- Pembayaran belum ada. Jangan menjual akses premium sebelum Tahap 4 selesai dan diuji.

## Struktur file
- `supabase/schema.sql`: tabel, kebijakan keamanan, fungsi `is_admin()`
- `src/app/page.tsx`: katalog (membaca database)
- `src/app/admin/page.tsx`: CRUD tool; `src/app/admin/categories/page.tsx`: kategori
- `src/app/login/page.tsx`: login admin
- `src/middleware.ts`: penjaga halaman /admin
- `src/lib/supabase/`: koneksi Supabase (browser dan server)

---

# Tahap 4a + 4b: pengguna, langganan, dan tool premium terkunci

Yang ditambahkan: daftar akun (email, kata sandi, kontak), halaman Akun, tabel paket dan langganan,
admin pengguna (aktifkan langganan manual), admin paket, dan tool premium yang file HTML-nya disimpan
privat di Supabase Storage lalu disajikan lewat `/t/<slug>` hanya untuk pelanggan aktif.

Belum ada (Tahap 4c): pembayaran otomatis, aktivasi otomatis, dan pengiriman link login otomatis.
Itu butuh akun payment gateway dan layanan pengirim pesan.

## Langkah pembaruan
1. Supabase > SQL Editor > New query: tempel seluruh isi `supabase/stage4.sql`, lalu Run.
2. Supabase > Authentication > URL Configuration: isi **Site URL** dengan alamat website Anda
   (https://...vercel.app) dan tambahkan alamat yang sama diikuti `/**` di **Redirect URLs**.
   Tanpa ini, email konfirmasi mengarah ke alamat yang salah.
3. Unggah zip ini ke repository GitHub (workflow "Unzip project" menimpa file lama). Vercel otomatis deploy ulang.
4. (Opsional) Vercel > Settings > Environment Variables: tambah `NEXT_PUBLIC_ADMIN_WHATSAPP`
   berisi nomor WhatsApp admin, contoh `6281234567890`, lalu Redeploy.

## Cara memakai
- Tool gratis: tetap lewat URL publik (GitHub Pages) seperti sebelumnya.
- Tool premium: di Kelola Tool pilih Jenis akses **Premium**, lalu unggah file `.html`.
  Jangan isi URL publik. Setelah itu tool hanya terbuka lewat website ini setelah login.
- Aktifkan langganan: menu **Pengguna**, pilih paket, klik **Aktifkan**. Menu **Paket** untuk mengubah harga dan durasi.

## Uji nyata
- [ ] Daftar akun baru di /daftar, konfirmasi lewat email, lalu masuk.
- [ ] Buka tool premium (tombol Buka Tool): belum berlangganan, Anda diarahkan ke halaman Akun.
- [ ] Sebagai admin, aktifkan langganan akun itu. Buka lagi tool premium: file tampil.
- [ ] Keluar lalu buka alamat /t/<slug> langsung: diarahkan ke login.
- [ ] Nonaktifkan langganan: tool premium kembali terkunci.
- [ ] Alamat file premium di Storage tidak bisa dibuka tanpa login (bucket privat).

## Catatan jujur
- Email bawaan Supabase dibatasi jumlahnya per jam dan hanya cocok untuk uji coba. Untuk pengguna sungguhan, pasang SMTP sendiri (Supabase > Authentication > SMTP Settings).
- Pelanggan aktif yang membuka tool premium menerima kode HTML-nya di browser. Itu sifat tool berbentuk file HTML. Jangan menaruh kunci API atau rahasia di dalam file HTML.
- Hanya ada satu paket: sekali beli, seumur hidup (dicatat sebagai 36500 hari). Satu pembelian membuka semua tool premium. Paket per tool belum ada.
- Pembayaran belum ada. Jangan menjual akses sebelum Tahap 4c selesai dan diuji dengan transaksi nyata (sandbox dulu).
